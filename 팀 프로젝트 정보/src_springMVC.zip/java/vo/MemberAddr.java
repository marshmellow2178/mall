package vo;
import java.util.*;

public class MemberAddr {
	private int ma_idx;
	private String mi_id, ma_name, ma_rname, ma_phone, ma_zip, ma_addr1, ma_addr2, ma_basic, ma_date;
	public int getMa_idx() {
		return ma_idx;
	}
	public void setMa_idx(int ma_idx) {
		this.ma_idx = ma_idx;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getMa_name() {
		return ma_name;
	}
	public void setMa_name(String ma_name) {
		this.ma_name = ma_name;
	}
	public String getMa_rname() {
		return ma_rname;
	}
	public void setMa_rname(String ma_rname) {
		this.ma_rname = ma_rname;
	}
	public String getMa_phone() {
		return ma_phone;
	}
	public void setMa_phone(String ma_phone) {
		this.ma_phone = ma_phone;
	}
	public String getMa_zip() {
		return ma_zip;
	}
	public void setMa_zip(String ma_zip) {
		this.ma_zip = ma_zip;
	}
	public String getMa_addr1() {
		return ma_addr1;
	}
	public void setMa_addr1(String ma_addr1) {
		this.ma_addr1 = ma_addr1;
	}
	public String getMa_addr2() {
		return ma_addr2;
	}
	public void setMa_addr2(String ma_addr2) {
		this.ma_addr2 = ma_addr2;
	}
	public String getMa_basic() {
		return ma_basic;
	}
	public void setMa_basic(String ma_basic) {
		this.ma_basic = ma_basic;
	}
	public String getMa_date() {
		return ma_date;
	}
	public void setMa_date(String ma_date) {
		this.ma_date = ma_date;
	}
	
}
