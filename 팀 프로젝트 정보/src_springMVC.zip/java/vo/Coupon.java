package vo;

public class Coupon {
	private int mc_idx;
	private String mi_id, mc_name, mc_kind, mc_sdate, mc_edate, mc_status;
	public int getMc_idx() {
		return mc_idx;
	}
	public void setMc_idx(int mc_idx) {
		this.mc_idx = mc_idx;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getMc_name() {
		return mc_name;
	}
	public void setMc_name(String mc_name) {
		this.mc_name = mc_name;
	}
	public String getMc_kind() {
		return mc_kind;
	}
	public void setMc_kind(String mc_kind) {
		this.mc_kind = mc_kind;
	}
	public String getMc_sdate() {
		return mc_sdate;
	}
	public void setMc_sdate(String mc_sdate) {
		this.mc_sdate = mc_sdate;
	}
	public String getMc_edate() {
		return mc_edate;
	}
	public void setMc_edate(String mc_edate) {
		this.mc_edate = mc_edate;
	}
	public String getMc_status() {
		return mc_status;
	}
	public void setMc_status(String mc_status) {
		this.mc_status = mc_status;
	}
}
