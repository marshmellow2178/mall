package vo;

public class MemtomemInfo {
	int bm_idx;
	String mi_id, bm_ctgr, bm_title, bm_content, bm_img1, bm_img2,
	bm_ip, bm_qdate, bf_isend;
	public int getBm_idx() {
		return bm_idx;
	}
	public void setBm_idx(int bm_idx) {
		this.bm_idx = bm_idx;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getBm_ctgr() {
		return bm_ctgr;
	}
	public void setBm_ctgr(String bm_ctgr) {
		this.bm_ctgr = bm_ctgr;
	}
	public String getBm_title() {
		return bm_title;
	}
	public void setBm_title(String bm_title) {
		this.bm_title = bm_title;
	}
	public String getBm_content() {
		return bm_content;
	}
	public void setBm_content(String bm_content) {
		this.bm_content = bm_content;
	}
	public String getBm_img1() {
		return bm_img1;
	}
	public void setBm_img1(String bm_img1) {
		this.bm_img1 = bm_img1;
	}
	public String getBm_img2() {
		return bm_img2;
	}
	public void setBm_img2(String bm_img2) {
		this.bm_img2 = bm_img2;
	}
	public String getBm_ip() {
		return bm_ip;
	}
	public void setBm_ip(String bm_ip) {
		this.bm_ip = bm_ip;
	}
	public String getBm_qdate() {
		return bm_qdate;
	}
	public void setBm_qdate(String bm_qdate) {
		this.bm_qdate = bm_qdate;
	}
	public String getBf_isend() {
		return bf_isend;
	}
	public void setBf_isend(String bf_isend) {
		this.bf_isend = bf_isend;
	}

}
