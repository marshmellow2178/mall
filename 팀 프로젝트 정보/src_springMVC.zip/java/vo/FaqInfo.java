package vo;

public class FaqInfo {
	int bf_idx, ai_idx;
	String bf_ctgr, bf_title, bf_content, bf_img1, bf_img2, bf_answer,
	bf_adate, bf_isview, ai_name;
	public int getBf_idx() {
		return bf_idx;
	}
	public void setBf_idx(int bf_idx) {
		this.bf_idx = bf_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getBf_ctgr() {
		return bf_ctgr;
	}
	public void setBf_ctgr(String bf_ctgr) {
		this.bf_ctgr = bf_ctgr;
	}
	public String getBf_title() {
		return bf_title;
	}
	public void setBf_title(String bf_title) {
		this.bf_title = bf_title;
	}
	public String getBf_content() {
		return bf_content;
	}
	public void setBf_content(String bf_content) {
		this.bf_content = bf_content;
	}
	public String getBf_img1() {
		return bf_img1;
	}
	public void setBf_img1(String bf_img1) {
		this.bf_img1 = bf_img1;
	}
	public String getBf_img2() {
		return bf_img2;
	}
	public void setBf_img2(String bf_img2) {
		this.bf_img2 = bf_img2;
	}
	public String getBf_answer() {
		return bf_answer;
	}
	public void setBf_answer(String bf_answer) {
		this.bf_answer = bf_answer;
	}
	public String getBf_adate() {
		return bf_adate;
	}
	public void setBf_adate(String bf_adate) {
		this.bf_adate = bf_adate;
	}
	public String getBf_isview() {
		return bf_isview;
	}
	public void setBf_isview(String bf_isview) {
		this.bf_isview = bf_isview;
	}
	public String getAi_name() {
		return ai_name;
	}
	public void setAi_name(String ai_name) {
		this.ai_name = ai_name;
	}
	

}
