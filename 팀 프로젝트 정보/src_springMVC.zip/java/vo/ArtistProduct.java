package vo;

public class ArtistProduct {
	//��ǰ �Һз� t_artist_product
	private String ac_id, ap_id, ap_name; //��Ƽ��Ʈ �ڵ�, �Һз� �ڵ�, �Һз� �̸�

	public String getAc_id() {
		return ac_id;
	}

	public void setAc_id(String ac_id) {
		this.ac_id = ac_id;
	}

	public String getAp_id() {
		return ap_id;
	}

	public void setAp_id(String ap_id) {
		this.ap_id = ap_id;
	}

	public String getAp_name() {
		return ap_name;
	}

	public void setAp_name(String ap_name) {
		this.ap_name = ap_name;
	}
	
	
}
