package db;

import java.sql.*;
import javax.sql.*;
import javax.naming.*;

public class JdbcUtil {
	public static Connection getConnection() {
		Connection conn = null;
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context)initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource)envCtx.lookup("jdbc/MySQL80");
			conn = ds.getConnection();
			conn.setAutoCommit(false);
		}
		catch(Exception e) {
			System.out.println("db연결 실패");
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void close(Connection conn) {
		try { conn.close(); }
		catch(Exception e) { e.printStackTrace(); }
	}
	
	public static void close(Statement stmt) {
		//prepared, callableStatement�� Statement�� ��ӹ����Ƿ� �޼ҵ带 ���� ���
		try { stmt.close(); }
		catch(Exception e) { e.printStackTrace(); }
	}
	
	public static void close(ResultSet rs) {
		try { rs.close(); }
		catch(Exception e) { e.printStackTrace(); }
	}
	
	public static void commit(Connection conn) {
		//transaction�� commit
		try {
			conn.commit();
			//System.out.println("jdbcutil: ���� ����");
		}
		catch(Exception e) { e.printStackTrace(); }
	}
	
	public static void rollback(Connection conn) {
		//transaction�� commit
		try {
			conn.rollback();
			System.out.println("jdbcutil: 쿼리 실패");
		}
		catch(Exception e) { e.printStackTrace(); }
	}
}
