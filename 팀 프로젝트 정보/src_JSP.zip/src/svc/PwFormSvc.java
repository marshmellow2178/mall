package svc;

import static db.JdbcUtil.*;
import java.util.*;
import java.sql.*;
import dao.*;
import vo.*;

public class PwFormSvc {
	public MemberAddr checkPw(String chkPw) {
		Connection conn = getConnection();
		MyPageDao  myPageDao  = MyPageDao .getInstance();
		myPageDao.setConnection(conn);

		MemberAddr memberAddr = myPageDao.checkPw(chkPw);
		
		close(conn);
		 
		return memberAddr;
	}
}
