package svc;

import static db.JdbcUtil.*;
import java.util.*;
import java.sql.*;
import dao.*;
import vo.*;

public class LoginFormSvc {
		public MemberInfo getLoginInfo(String uid, String pwd) {
			Connection conn = getConnection();
			LoginFormDao loginDao = LoginFormDao.getInstance();
			loginDao.setConnection(conn);

			MemberInfo loginInfo = loginDao.getLoginInfo(uid, pwd);
			close(conn);
			
			return loginInfo;
		}
		public MemberInfo getHiddenLoginInfo(String uid) {
			Connection conn = getConnection();
			LoginFormDao loginDao = LoginFormDao.getInstance();
			loginDao.setConnection(conn);

			MemberInfo hiddenLoginInfo = loginDao.getHiddenLoginInfo(uid);
			close(conn);
			
			return hiddenLoginInfo;
		}
	}
