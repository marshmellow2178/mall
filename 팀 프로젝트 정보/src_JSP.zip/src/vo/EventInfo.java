package vo;

public class EventInfo 
{
	private int be_idx, ai_idx;
	private String be_title, be_content, be_img1, be_img2, be_date, be_sdate, be_edate, be_status, be_isview;
	
	public int getBe_idx() {
		return be_idx;
	}
	public void setBe_idx(int be_idx) {
		this.be_idx = be_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getBe_title() {
		return be_title;
	}
	public void setBe_title(String be_title) {
		this.be_title = be_title;
	}
	public String getBe_content() {
		return be_content;
	}
	public void setBe_content(String be_content) {
		this.be_content = be_content;
	}
	public String getBe_img1() {
		return be_img1;
	}
	public void setBe_img1(String be_img1) {
		this.be_img1 = be_img1;
	}
	public String getBe_img2() {
		return be_img2;
	}
	public void setBe_img2(String be_img2) {
		this.be_img2 = be_img2;
	}
	public String getBe_date() {
		return be_date;
	}
	public void setBe_date(String be_date) {
		this.be_date = be_date;
	}
	public String getBe_sdate() {
		return be_sdate;
	}
	public void setBe_sdate(String be_sdate) {
		this.be_sdate = be_sdate;
	}
	public String getBe_edate() {
		return be_edate;
	}
	public void setBe_edate(String be_edate) {
		this.be_edate = be_edate;
	}
	public String getBe_status() {
		return be_status;
	}
	public void setBe_status(String be_status) {
		this.be_status = be_status;
	}
	public String getBe_isview() {
		return be_isview;
	}
	public void setBe_isview(String be_isview) {
		this.be_isview = be_isview;
	}
}
