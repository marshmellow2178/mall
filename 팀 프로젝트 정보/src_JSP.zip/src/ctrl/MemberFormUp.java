package ctrl;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/member_form_up")
public class MemberFormUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public MemberFormUp() { super();}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//post: form method = post �� ���� post������� ����
		HttpSession session = request.getSession();
		if(session.getAttribute("loginInfo")==null) {
			response.setContentType("text/html; charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('�α����ϼ���');");
			out.println("location.href = 'login_form.jsp';");
			out.println("</script>");
			out.close();
		}
			RequestDispatcher dispatcher = request.getRequestDispatcher("member/member_up.jsp");
			dispatcher.forward(request, response);
			//sendredirect: url ���� dispatcher: ���� �ȵ� > ���ΰ�ħ�ϸ� �ȵǴ°�(proc)�� �ּҸ� �����Ѵ�
	}

}
